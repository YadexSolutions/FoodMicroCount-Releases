Version-matched attribution records and license files from Qt 6.12.0.
Upstream source archives and SHA-256 values:
a951bd163c7b80fc6b8c88d7668fb56abf91c152373e13c10666763238131307  https://download.qt.io/official_releases/qt/6.12/6.12.0/submodules/qtbase-everywhere-src-6.12.0.tar.xz
e4ab39534ec97987b1b9b60ef7f4d3253d5912a69f8c713a01753174a4029331  https://download.qt.io/official_releases/qt/6.12/6.12.0/submodules/qtsvg-everywhere-src-6.12.0.tar.xz
0943132b5db8de6b6a7f1d162682173e8763c7ed94e80fd39113292845f67762  https://download.qt.io/official_releases/qt/6.12/6.12.0/submodules/qtimageformats-everywhere-src-6.12.0.tar.xz
